#version 150

uniform int isEyeInWater; // Variable de OptiFine para detectar si el ojo está en agua

vec4 linear_fog(vec4 inColor, float vertexDistance, float fogStart, float fogEnd, vec4 fogColor) {
    // Ajustes originales del usuario
    float modifiedFogStart = fogStart * -0.40;  // Empieza antes
    float modifiedFogEnd = fogEnd * 1.15;       // Termina mucho más lejos

    // Depuración: forzar color rojo puro bajo el agua para verificar isEyeInWater
    if (isEyeInWater == 1) {
        return vec4(1.0, 0.0, 0.0, 1.0); // Color rojo puro para depuración
    }

    if (vertexDistance <= modifiedFogStart) {
        return inColor;
    }

    float fogValue = vertexDistance < modifiedFogEnd ? smoothstep(modifiedFogStart, modifiedFogEnd, vertexDistance) : 1.0;
    return vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a);
}

float linear_fog_fade(float vertexDistance, float fogStart, float fogEnd) {
    // Ajustes originales del usuario
    float modifiedFogStart = fogStart * 0.0;  // Empieza antes
    float modifiedFogEnd = fogEnd * 1.0;     // Termina más lejos

    // Depuración: devolver 0.0 bajo el agua para verificar isEyeInWater
    if (isEyeInWater == 1) {
        return 0.0; // Valor extremo para depuración
    }

    if (vertexDistance <= modifiedFogStart) {
        return 1.0;
    } else if (vertexDistance >= modifiedFogEnd) {
        return 0.0;
    }

    return smoothstep(modifiedFogEnd, modifiedFogStart, vertexDistance);
}

float fog_distance(vec3 pos, int shape) {
    if (shape == 0) {
        return length(pos);
    } else {
        float distXZ = length(pos.xz);
        float distY = abs(pos.y);
        return max(distXZ, distY);
    }
}